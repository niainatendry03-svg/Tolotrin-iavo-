TOLOTRIN'IAVO AMBAIBOHO — PROJET ANDROID
=========================================

Ce dossier contient le projet source d'une application Android de gestion de restaurant.
L'application fonctionne hors connexion et conserve les données sur l'appareil.

FONCTIONS
- Menu de plats avec prix et photo facultative
- Commandes et calcul automatique des totaux
- Suivi des dépenses
- Gestion simple du stock
- Tableau de bord et historique
- Exportation / importation d'une sauvegarde JSON

MENU INITIAL
- Côtelette salade : 6 000 Ar
- Henakisoa : 6 000 Ar
- Hen'omby : 6 000 Ar
- Trondro frit / sauce : 6 000 Ar (prix modifiable)

IMPORTANT : CE N'EST PAS ENCORE LE FICHIER APK.
Le projet Android est prêt à être ouvert et compilé avec Android Studio. La compilation
APK nécessite Android Studio/Android SDK sur un ordinateur.

COMMENT OBTENIR L'APK
1. Installer Android Studio sur un ordinateur.
2. Décompresser ce ZIP.
3. Dans Android Studio, choisir "Open" et sélectionner le dossier TolotrinIavo_Android_Project.
4. Attendre la synchronisation Gradle et l'installation des composants Android SDK demandés.
5. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
6. À la fin, Android Studio affiche un lien "locate" vers l'APK généré.
7. Transférer l'APK sur le téléphone Android et l'installer. Android peut demander d'autoriser
   l'installation depuis cette source.

CONFIDENTIALITÉ ET SAUVEGARDE
- Pas de compte ni de connexion Internet requis.
- Les données sont stockées localement dans l'application sur le téléphone.
- Exporter régulièrement une sauvegarde depuis l'onglet Historique.
- Désinstaller l'application ou effacer ses données peut supprimer les données locales.

Le projet a été préparé comme première version personnelle. Vérifier les calculs et faire
une sauvegarde avant de l'utiliser pour la comptabilité réelle du restaurant.
